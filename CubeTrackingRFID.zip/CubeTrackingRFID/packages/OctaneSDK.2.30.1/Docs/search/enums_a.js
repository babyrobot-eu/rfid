var searchData=
[
  ['readermode',['ReaderMode',['../namespace_impinj_1_1_octane_sdk.html#a4c4c3a5adf0a8a35f0a6b0f0fc14b438',1,'Impinj::OctaneSdk']]],
  ['readermodel',['ReaderModel',['../namespace_impinj_1_1_octane_sdk.html#aa2f582fa3afc074cd28072652daeebaf',1,'Impinj::OctaneSdk']]],
  ['readresultstatus',['ReadResultStatus',['../namespace_impinj_1_1_octane_sdk.html#a5036e46cc73883bdc9c117080074edb2',1,'Impinj::OctaneSdk']]],
  ['reportmode',['ReportMode',['../namespace_impinj_1_1_octane_sdk.html#ad34181e7bbd29961671edde24b9fc885',1,'Impinj::OctaneSdk']]],
  ['rospeceventtype',['RoSpecEventType',['../namespace_impinj_1_1_octane_sdk.html#a4df960c144f4f0bbaad7ce5990688654',1,'Impinj::OctaneSdk']]],
  ['rshellcmdstatus',['RShellCmdStatus',['../namespace_impinj_1_1_octane_sdk.html#a57a4b65762c413b2831c6910ad556ec4',1,'Impinj::OctaneSdk']]],
  ['rshellconnectiontype',['RShellConnectionType',['../namespace_impinj_1_1_octane_sdk.html#a4722f5396b48d18c05f2d71d1fd83395',1,'Impinj::OctaneSdk']]]
];
