var searchData=
[
  ['name',['Name',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a715b35febf80c4a5786b3dc52d423ebd',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
