var searchData=
[
  ['channelinmhz',['ChannelInMhz',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a9227a592a2e9488d2455c52d89081df5',1,'Impinj::OctaneSdk::Tag']]],
  ['communicationsstandard',['CommunicationsStandard',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html#a6e66111c75d6bd746f15b09b4d758bad',1,'Impinj::OctaneSdk::FeatureSet']]],
  ['computewindowseconds',['ComputeWindowSeconds',['../class_impinj_1_1_octane_sdk_1_1_location_config.html#a3b496bcda25d0d424d419aa305a87a88',1,'Impinj::OctaneSdk::LocationConfig']]],
  ['confidencefactors',['ConfidenceFactors',['../class_impinj_1_1_octane_sdk_1_1_location_report.html#a7386419725184c3174eed7b63d48f1c9',1,'Impinj::OctaneSdk::LocationReport']]],
  ['connected',['Connected',['../class_impinj_1_1_octane_sdk_1_1_antenna_hub_status.html#a3d5ad3e37d2382680f01d793820e992c',1,'Impinj::OctaneSdk::AntennaHubStatus']]],
  ['connection',['Connection',['../class_impinj_1_1_octane_sdk_1_1_status.html#a33682ee61ae42a3d0f5795b601153fb8',1,'Impinj::OctaneSdk::Status']]],
  ['connecttimeout',['ConnectTimeout',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a996fe4bdca3803201fa1eaf60bcd0e93',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['countbytes',['CountBytes',['../class_impinj_1_1_octane_sdk_1_1_tag_data.html#a40ada4ab61ae3ae9b7378ae2d31c0eae',1,'Impinj::OctaneSdk::TagData']]],
  ['crc',['Crc',['../class_impinj_1_1_octane_sdk_1_1_tag.html#af9c2d509b94781abd31e09c4ab360453',1,'Impinj::OctaneSdk::Tag']]]
];
