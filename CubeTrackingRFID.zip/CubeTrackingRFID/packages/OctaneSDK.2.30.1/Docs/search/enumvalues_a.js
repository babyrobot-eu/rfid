var searchData=
[
  ['killpassword',['KillPassword',['../namespace_impinj_1_1_octane_sdk.html#aad034f83d9b1f2d946584a2f082e5fd0a874ce44cee88251c0aa277c98cafb661',1,'Impinj::OctaneSdk']]],
  ['korea_5fmic_5farticle_5f5_5f2',['Korea_MIC_Article_5_2',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178af0c8821af0261027256a47c3442929ea',1,'Impinj::OctaneSdk']]]
];
