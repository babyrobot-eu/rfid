var searchData=
[
  ['readerstarted',['ReaderStarted',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#af219c6d0d12defa488c13b84bd59693c',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['readerstopped',['ReaderStopped',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#afad29e7c7a1f11d912ee5d1812fdd6a3',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['reportbufferoverflow',['ReportBufferOverflow',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a5c0437131304133279290da618ff8601',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['reportbufferwarning',['ReportBufferWarning',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a9d689bc77c4455a90ef256455dcc7abb',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
