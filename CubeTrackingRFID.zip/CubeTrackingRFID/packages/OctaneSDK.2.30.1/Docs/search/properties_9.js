var searchData=
[
  ['keepalives',['Keepalives',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a636e887be85aa84f2b3bc856dc2e3e55',1,'Impinj::OctaneSdk::Settings']]],
  ['killpasswordlocktype',['KillPasswordLockType',['../class_impinj_1_1_octane_sdk_1_1_tag_lock_op.html#af98ac3955dacfccd260f3fcf0357701b',1,'Impinj::OctaneSdk::TagLockOp']]],
  ['killresult',['KillResult',['../class_impinj_1_1_octane_sdk_1_1_kill_tag_result.html#a6a8db09fe5ede05bd387dcea65ddd44f',1,'Impinj.OctaneSdk.KillTagResult.KillResult()'],['../class_impinj_1_1_octane_sdk_1_1_read_tag_memory_result.html#ac6735f86028c7902d870f83641239bce',1,'Impinj.OctaneSdk.ReadTagMemoryResult.KillResult()']]]
];
