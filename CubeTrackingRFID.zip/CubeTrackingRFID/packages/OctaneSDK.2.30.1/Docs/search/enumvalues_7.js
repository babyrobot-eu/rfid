var searchData=
[
  ['highperformance',['HighPerformance',['../namespace_impinj_1_1_octane_sdk.html#ad934a5eb92c6e0396e1e49bfd403b3a7afc3d9ab96ac1103a7581af5eade2ad15',1,'Impinj::OctaneSdk']]],
  ['highsensitivity',['HighSensitivity',['../namespace_impinj_1_1_octane_sdk.html#ad934a5eb92c6e0396e1e49bfd403b3a7ac70c8b65f75e936ad318d4bd59357726',1,'Impinj::OctaneSdk']]],
  ['hong_5fkong_5fofta_5f1049',['Hong_Kong_OFTA_1049',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178a5d23c7ebf568de93baf9905d87d9392b',1,'Impinj::OctaneSdk']]],
  ['hybrid',['Hybrid',['../namespace_impinj_1_1_octane_sdk.html#a4c4c3a5adf0a8a35f0a6b0f0fc14b438afb1b6e23a3767d2a31ef7899e6dd3f1e',1,'Impinj::OctaneSdk']]]
];
