var searchData=
[
  ['sectorconfig',['SectorConfig',['../class_impinj_1_1_octane_sdk_1_1_sector_config.html',1,'Impinj::OctaneSdk']]],
  ['settings',['Settings',['../class_impinj_1_1_octane_sdk_1_1_settings.html',1,'Impinj::OctaneSdk']]],
  ['spatialconfig',['SpatialConfig',['../class_impinj_1_1_octane_sdk_1_1_spatial_config.html',1,'Impinj::OctaneSdk']]],
  ['status',['Status',['../class_impinj_1_1_octane_sdk_1_1_status.html',1,'Impinj::OctaneSdk']]]
];
