var searchData=
[
  ['searchmode',['SearchMode',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a4969d45a6694389e4eed2c0edc5dc353',1,'Impinj::OctaneSdk::Settings']]],
  ['sectorid',['SectorId',['../class_impinj_1_1_octane_sdk_1_1_sector_config.html#a27af2654511b955925d7d4c689525205',1,'Impinj::OctaneSdk::SectorConfig']]],
  ['serializedtid',['SerializedTid',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a189da449bf1002dff77da61349074e2f',1,'Impinj::OctaneSdk::Tag']]],
  ['serialnumber',['SerialNumber',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html#a0c55fbff0014ad500a5b415172908294',1,'Impinj::OctaneSdk::FeatureSet']]],
  ['session',['Session',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a58193038b3985e914c702da4a42d815c',1,'Impinj::OctaneSdk::Settings']]],
  ['softwareversion',['SoftwareVersion',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html#aa28be3c8b0c8501c726b4d19b2267ae8',1,'Impinj::OctaneSdk::FeatureSet']]],
  ['spatialconfig',['SpatialConfig',['../class_impinj_1_1_octane_sdk_1_1_settings.html#ab7aca5d9f38b7ebc0057d4bdb0eab2d7',1,'Impinj::OctaneSdk::Settings']]],
  ['state',['State',['../class_impinj_1_1_octane_sdk_1_1_antenna_status.html#a2e7705e0dba1cdcac7853ba5c22716b1',1,'Impinj.OctaneSdk.AntennaStatus.State()'],['../class_impinj_1_1_octane_sdk_1_1_gpi_status.html#ab9d065718a3b1dd3bf9ea096b4db189b',1,'Impinj.OctaneSdk.GpiStatus.State()']]],
  ['supportsqt',['SupportsQt',['../class_impinj_1_1_octane_sdk_1_1_tag_model_details.html#a52c87c5c486a92aeedc76a021890e9bf',1,'Impinj::OctaneSdk::TagModelDetails']]]
];
