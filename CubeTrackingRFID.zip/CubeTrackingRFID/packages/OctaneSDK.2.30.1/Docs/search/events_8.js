var searchData=
[
  ['tagopcomplete',['TagOpComplete',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a65dd6c4bb011f6c3dcfd752e49192d50',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['tagsreported',['TagsReported',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a237805b0c65ad13d1e61a792a184cfba',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
