var searchData=
[
  ['locationreported',['LocationReported',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a253c6552b1189710870fbd9705b2e5c4',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
