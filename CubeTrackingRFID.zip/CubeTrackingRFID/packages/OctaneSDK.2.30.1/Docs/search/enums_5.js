var searchData=
[
  ['hubconnectedstatus',['HubConnectedStatus',['../namespace_impinj_1_1_octane_sdk.html#a04b004158e90a2e5da4f16119954197f',1,'Impinj::OctaneSdk']]],
  ['hubfaultstatus',['HubFaultStatus',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7ee',1,'Impinj::OctaneSdk']]]
];
