var searchData=
[
  ['searchmode',['SearchMode',['../namespace_impinj_1_1_octane_sdk.html#a458a36c55208763f6be9bde886c0cbc0',1,'Impinj::OctaneSdk']]],
  ['sequencestate',['SequenceState',['../namespace_impinj_1_1_octane_sdk.html#a4f7180b36eeb74bb3ab40b1d58ecc553',1,'Impinj::OctaneSdk']]],
  ['sequencetriggertype',['SequenceTriggerType',['../namespace_impinj_1_1_octane_sdk.html#a63f246702ea194bb1d6b910cf2a5de89',1,'Impinj::OctaneSdk']]],
  ['spatialmode',['SpatialMode',['../namespace_impinj_1_1_octane_sdk.html#a5967507dfc6e5ee92229ddf1e340c55c',1,'Impinj::OctaneSdk']]]
];
