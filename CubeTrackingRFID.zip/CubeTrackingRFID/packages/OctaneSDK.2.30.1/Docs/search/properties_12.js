var searchData=
[
  ['updateintervalseconds',['UpdateIntervalSeconds',['../class_impinj_1_1_octane_sdk_1_1_direction_config.html#a7c0c2236f322d3ce3bedcd6ec3db84fb',1,'Impinj.OctaneSdk.DirectionConfig.UpdateIntervalSeconds()'],['../class_impinj_1_1_octane_sdk_1_1_location_config.html#a070ec5300b37bdd26cb74d5f65624660',1,'Impinj.OctaneSdk.LocationConfig.UpdateIntervalSeconds()']]],
  ['updatereportenabled',['UpdateReportEnabled',['../class_impinj_1_1_octane_sdk_1_1_direction_config.html#a9809a150136adee870915c439bd255f6',1,'Impinj.OctaneSdk.DirectionConfig.UpdateReportEnabled()'],['../class_impinj_1_1_octane_sdk_1_1_location_config.html#a7a258fcac7f26ef04b4d6ef32e7697c7',1,'Impinj.OctaneSdk.LocationConfig.UpdateReportEnabled()']]],
  ['userlocktype',['UserLockType',['../class_impinj_1_1_octane_sdk_1_1_tag_lock_op.html#a5f339be0624cb89ad618352703fb83ca',1,'Impinj::OctaneSdk::TagLockOp']]],
  ['usermemorysizebits',['UserMemorySizeBits',['../class_impinj_1_1_octane_sdk_1_1_tag_model_details.html#a9c305a2559942f6538a6f35f7bb490f0',1,'Impinj::OctaneSdk::TagModelDetails']]],
  ['utc',['Utc',['../class_impinj_1_1_octane_sdk_1_1_impinj_timestamp.html#af90edf9304d6cae65ac980b03196152b',1,'Impinj::OctaneSdk::ImpinjTimestamp']]],
  ['utctimestamp',['UtcTimestamp',['../class_impinj_1_1_octane_sdk_1_1_auto_start_config.html#a86d4b2a3466a9dac457998cf6eade5a3',1,'Impinj::OctaneSdk::AutoStartConfig']]]
];
