var searchData=
[
  ['gpitrigger',['GpiTrigger',['../namespace_impinj_1_1_octane_sdk.html#abf79cf473332c728986b050af4993169a4e201eaa6967ff34944342a69cbb862c',1,'Impinj.OctaneSdk.GpiTrigger()'],['../namespace_impinj_1_1_octane_sdk.html#a652ab8d9bd0a977e6e06023c511e24b7a4e201eaa6967ff34944342a69cbb862c',1,'Impinj.OctaneSdk.GpiTrigger()']]]
];
