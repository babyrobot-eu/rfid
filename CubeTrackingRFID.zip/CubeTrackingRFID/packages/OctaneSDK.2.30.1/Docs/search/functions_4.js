var searchData=
[
  ['enableopsequence',['EnableOpSequence',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a594c59810312e91a851f475a8a30b9c2',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
