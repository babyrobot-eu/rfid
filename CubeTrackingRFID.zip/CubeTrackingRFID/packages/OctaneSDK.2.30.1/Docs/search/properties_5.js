var searchData=
[
  ['facilityxlocationcm',['FacilityXLocationCm',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html#a0e36209cbeee4332be27cb52b555bb99',1,'Impinj::OctaneSdk::PlacementConfig']]],
  ['facilityylocationcm',['FacilityYLocationCm',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html#a8392d3b098650ddc5cbe36e4c3e04761',1,'Impinj::OctaneSdk::PlacementConfig']]],
  ['fault',['Fault',['../class_impinj_1_1_octane_sdk_1_1_antenna_hub_status.html#ac05a10e2d0ccadd77875ab8c3ad59216',1,'Impinj::OctaneSdk::AntennaHubStatus']]],
  ['fieldofview',['FieldOfView',['../class_impinj_1_1_octane_sdk_1_1_direction_config.html#a5ef81ef05d384e75c510fa3aa069ee45',1,'Impinj::OctaneSdk::DirectionConfig']]],
  ['fieldpingintervalinms',['FieldPingIntervalInMs',['../class_impinj_1_1_octane_sdk_1_1_low_duty_cycle_settings.html#a01d98d47f66032db3723bf4b6f0fef24',1,'Impinj::OctaneSdk::LowDutyCycleSettings']]],
  ['filterop',['FilterOp',['../class_impinj_1_1_octane_sdk_1_1_tag_filter.html#aefb1dd89637777e2aa0d7cdfff4f952f',1,'Impinj::OctaneSdk::TagFilter']]],
  ['filters',['Filters',['../class_impinj_1_1_octane_sdk_1_1_settings.html#ac42994caecd976ca07c744feb10d20ca',1,'Impinj::OctaneSdk::Settings']]],
  ['firmwareversion',['FirmwareVersion',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html#acdf9aca9e7ea63b62302e6367c0d9977',1,'Impinj::OctaneSdk::FeatureSet']]],
  ['firstdelayinms',['FirstDelayInMs',['../class_impinj_1_1_octane_sdk_1_1_auto_start_config.html#a9917d147212d2e91baf6440798e74134',1,'Impinj::OctaneSdk::AutoStartConfig']]],
  ['firstseensector',['FirstSeenSector',['../class_impinj_1_1_octane_sdk_1_1_direction_report.html#a40cc78937d774f1595ce4e71bc138a44',1,'Impinj::OctaneSdk::DirectionReport']]],
  ['firstseentime',['FirstSeenTime',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a41fc1d78948ab9a5e97ad33171b95e75',1,'Impinj::OctaneSdk::Tag']]],
  ['firstseentimestamp',['FirstSeenTimestamp',['../class_impinj_1_1_octane_sdk_1_1_direction_report.html#a291444af81c533ae4928be56dec9b631',1,'Impinj::OctaneSdk::DirectionReport']]]
];
