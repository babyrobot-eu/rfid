var searchData=
[
  ['featureset',['FeatureSet',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html',1,'Impinj::OctaneSdk']]],
  ['filtersettings',['FilterSettings',['../class_impinj_1_1_octane_sdk_1_1_filter_settings.html',1,'Impinj::OctaneSdk']]]
];
