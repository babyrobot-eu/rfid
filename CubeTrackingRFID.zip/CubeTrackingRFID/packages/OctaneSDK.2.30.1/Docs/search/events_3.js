var searchData=
[
  ['gpichanged',['GpiChanged',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#ac54f4e59747564ec1d03849984b41785',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
