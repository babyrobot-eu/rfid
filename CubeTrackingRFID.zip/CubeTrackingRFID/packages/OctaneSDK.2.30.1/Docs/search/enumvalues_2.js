var searchData=
[
  ['connected',['Connected',['../namespace_impinj_1_1_octane_sdk.html#a04b004158e90a2e5da4f16119954197fa2ec0d16e4ca169baedb9b2d50ec5c6d7',1,'Impinj::OctaneSdk']]]
];
