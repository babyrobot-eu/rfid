var searchData=
[
  ['load',['Load',['../class_impinj_1_1_octane_sdk_1_1_feature_set.html#a1ed73e3318a86782943f01d10e570ac9',1,'Impinj.OctaneSdk.FeatureSet.Load()'],['../class_impinj_1_1_octane_sdk_1_1_settings.html#a25ffe551cddeb6e1225501c722024cb4',1,'Impinj.OctaneSdk.Settings.Load()'],['../class_impinj_1_1_octane_sdk_1_1_status.html#a09c4d296afba6b58f0f3c39548329b13',1,'Impinj.OctaneSdk.Status.Load()']]]
];
