var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuwxyz",
  1: "abdfgiklmoprstx",
  2: "io",
  3: "abcdefgilmoqrst",
  4: "abdeikmnoprstw",
  5: "abcdghklmqrstwx",
  6: "abcdefghijklmnoprstuwxz",
  7: "abcdefghiklmnoprstuxy",
  8: "acdgklprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events"
};

