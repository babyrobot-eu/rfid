var searchData=
[
  ['operationstate',['OperationState',['../class_impinj_1_1_octane_sdk_1_1_status.html#a2a7b6dd4420c71fa5787ae509270cc9f',1,'Impinj::OctaneSdk::Status']]],
  ['optimizedreadops',['OptimizedReadOps',['../class_impinj_1_1_octane_sdk_1_1_report_config.html#ad1d7e5aeabdaf9d64f6603b779a03951',1,'Impinj::OctaneSdk::ReportConfig']]],
  ['orientationdegrees',['OrientationDegrees',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html#a83dee694189ec8812d2dd5a4dee80500',1,'Impinj::OctaneSdk::PlacementConfig']]]
];
