var searchData=
[
  ['keepalivereceived',['KeepaliveReceived',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#ac4cbbc348fe297477604c44e36d5cb07',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
