var searchData=
[
  ['keepaliveconfig',['KeepaliveConfig',['../class_impinj_1_1_octane_sdk_1_1_keepalive_config.html',1,'Impinj::OctaneSdk']]],
  ['killtagresult',['KillTagResult',['../class_impinj_1_1_octane_sdk_1_1_kill_tag_result.html',1,'Impinj::OctaneSdk']]]
];
