var searchData=
[
  ['blockpermalockresult',['BlockPermalockResult',['../namespace_impinj_1_1_octane_sdk.html#a95fae1afe8fed41c5a0c4b67271a0271',1,'Impinj::OctaneSdk']]]
];
