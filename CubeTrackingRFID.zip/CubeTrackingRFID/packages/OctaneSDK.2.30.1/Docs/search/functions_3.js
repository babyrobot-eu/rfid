var searchData=
[
  ['deleteallopsequences',['DeleteAllOpSequences',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#acaea7789526e4d73fd09c99b0e0f32ad',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['deleteopsequence',['DeleteOpSequence',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a8e348de14ce4886478a419bed12b8b61',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['disconnect',['Disconnect',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a715cac2d136ce84d90fcbf9e89c91336',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
