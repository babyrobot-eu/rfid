var searchData=
[
  ['getenumerator',['GetEnumerator',['../class_impinj_1_1_octane_sdk_1_1_tag_op_report.html#a59361efdac0e6bc291f6f004488ae046',1,'Impinj.OctaneSdk.TagOpReport.GetEnumerator()'],['../class_impinj_1_1_octane_sdk_1_1_tag_report.html#af595b9004504d445f5ba4a4ed31189dc',1,'Impinj.OctaneSdk.TagReport.GetEnumerator()']]],
  ['gpoconfig',['GpoConfig',['../class_impinj_1_1_octane_sdk_1_1_gpo_config.html#abc0b1b8aa5ba3fd9d2d2f10b0af17011',1,'Impinj::OctaneSdk::GpoConfig']]]
];
