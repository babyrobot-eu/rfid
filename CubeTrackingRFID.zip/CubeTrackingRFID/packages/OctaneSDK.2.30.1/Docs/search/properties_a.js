var searchData=
[
  ['lastreadsector',['LastReadSector',['../class_impinj_1_1_octane_sdk_1_1_direction_report.html#a253fba4af77af79667863ab03e263b14',1,'Impinj::OctaneSdk::DirectionReport']]],
  ['lastreadtimestamp',['LastReadTimestamp',['../class_impinj_1_1_octane_sdk_1_1_direction_report.html#a6f364884d45083ce04bba96cf4361801',1,'Impinj::OctaneSdk::DirectionReport']]],
  ['lastseentime',['LastSeenTime',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a01df6e8492089c5c2d9dfdb1c525c9b4',1,'Impinj::OctaneSdk::Tag']]],
  ['latitude',['Latitude',['../class_impinj_1_1_octane_sdk_1_1_gps_coordinates.html#a550dd2d71c678562dc2facfcb8cb7e1d',1,'Impinj::OctaneSdk::GpsCoordinates']]],
  ['linkdownthreshold',['LinkDownThreshold',['../class_impinj_1_1_octane_sdk_1_1_keepalive_config.html#acfd85b58326c05da3bc8ab1bf588da4e',1,'Impinj::OctaneSdk::KeepaliveConfig']]],
  ['localdatetime',['LocalDateTime',['../class_impinj_1_1_octane_sdk_1_1_impinj_timestamp.html#a8bd402efe2a878c2d610c66e90e45ea0',1,'Impinj::OctaneSdk::ImpinjTimestamp']]],
  ['location',['Location',['../class_impinj_1_1_octane_sdk_1_1_spatial_config.html#a3022948d89f97a86ce52ccee1cec81c7',1,'Impinj.OctaneSdk.SpatialConfig.Location()'],['../class_impinj_1_1_octane_sdk_1_1_x_array_config.html#a2eaea813b1010b500c55b1b7a446e8dc',1,'Impinj.OctaneSdk.XArrayConfig.Location()']]],
  ['locationalgorithmcontrol',['LocationAlgorithmControl',['../class_impinj_1_1_octane_sdk_1_1_location_config.html#aab0906ba3cb08c27d36034fbb99d0332',1,'Impinj::OctaneSdk::LocationConfig']]],
  ['locationxcm',['LocationXCm',['../class_impinj_1_1_octane_sdk_1_1_location_report.html#a85894c0b257a6a603e0053227a20fdeb',1,'Impinj::OctaneSdk::LocationReport']]],
  ['locationycm',['LocationYCm',['../class_impinj_1_1_octane_sdk_1_1_location_report.html#a533a191f55b5c7a4fc9bd94563b6b560',1,'Impinj::OctaneSdk::LocationReport']]],
  ['lockcount',['LockCount',['../class_impinj_1_1_octane_sdk_1_1_tag_lock_op.html#a13fb66708dbbe6fb0fe30653eb71d1e5',1,'Impinj::OctaneSdk::TagLockOp']]],
  ['lockresult',['LockResult',['../class_impinj_1_1_octane_sdk_1_1_lock_tag_result.html#afe4068be27127084c09a8acc3d151c4f',1,'Impinj.OctaneSdk.LockTagResult.LockResult()'],['../class_impinj_1_1_octane_sdk_1_1_read_tag_memory_result.html#a11c8d1e8ea7f01b4077d9ad8cd5da4b0',1,'Impinj.OctaneSdk.ReadTagMemoryResult.LockResult()']]],
  ['longitude',['Longitude',['../class_impinj_1_1_octane_sdk_1_1_gps_coordinates.html#a684c6180867734901fb8239b3f2a56a4',1,'Impinj::OctaneSdk::GpsCoordinates']]],
  ['lowdutycycle',['LowDutyCycle',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a16d214b3a2d0a38b306d5f1a91a2909b',1,'Impinj::OctaneSdk::Settings']]]
];
