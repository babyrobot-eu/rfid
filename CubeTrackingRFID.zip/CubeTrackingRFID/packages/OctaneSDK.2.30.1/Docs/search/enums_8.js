var searchData=
[
  ['marginreadresult',['MarginReadResult',['../namespace_impinj_1_1_octane_sdk.html#ab07f6d2eb75783233b1134ac6a4093d9',1,'Impinj::OctaneSdk']]],
  ['memorybank',['MemoryBank',['../namespace_impinj_1_1_octane_sdk.html#a4bd5d248896464d33e724b20013f8f8c',1,'Impinj::OctaneSdk']]]
];
