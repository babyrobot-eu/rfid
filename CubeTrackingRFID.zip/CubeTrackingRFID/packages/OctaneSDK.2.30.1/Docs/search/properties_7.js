var searchData=
[
  ['heightcm',['HeightCm',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html#a708f5f9e6944c5b0599d0240f03496d0',1,'Impinj::OctaneSdk::PlacementConfig']]],
  ['holdreportsondisconnect',['HoldReportsOnDisconnect',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a88847a0d0248f1d856e499f46ca86753',1,'Impinj::OctaneSdk::Settings']]],
  ['hubid',['HubId',['../class_impinj_1_1_octane_sdk_1_1_antenna_hub_status.html#a2b4779e1615d3227d32ace64c532844e',1,'Impinj::OctaneSdk::AntennaHubStatus']]]
];
