var searchData=
[
  ['marginreadmask',['MarginReadMask',['../class_impinj_1_1_octane_sdk_1_1_margin_read_mask.html#a1ab3d3759041ded12e34251cb3d7bf65',1,'Impinj::OctaneSdk::MarginReadMask']]]
];
