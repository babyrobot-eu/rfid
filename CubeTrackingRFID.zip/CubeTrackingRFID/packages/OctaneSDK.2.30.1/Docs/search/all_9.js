var searchData=
[
  ['japan_5farib_5fstd_5ft89',['Japan_ARIB_STD_T89',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178a70fe2e42515b1973b1c71d2f8ac457ed',1,'Impinj::OctaneSdk']]]
];
