var searchData=
[
  ['buildaddrospecmessage',['BuildAddROSpecMessage',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a0649416376468dec3d392517087d3c2b',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['buildsetreaderconfigmessage',['BuildSetReaderConfigMessage',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#aeedebcdb9a53ba2114b00669e4801326',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
