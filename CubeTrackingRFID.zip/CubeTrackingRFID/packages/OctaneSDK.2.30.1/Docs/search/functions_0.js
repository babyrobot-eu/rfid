var searchData=
[
  ['addopsequence',['AddOpSequence',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a4e66d72bf1e3cda3b98a6da277038800',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['antennaconfig',['AntennaConfig',['../class_impinj_1_1_octane_sdk_1_1_antenna_config.html#a1a4cd26ba8127dfda6313776035c44db',1,'Impinj.OctaneSdk.AntennaConfig.AntennaConfig()'],['../class_impinj_1_1_octane_sdk_1_1_antenna_config.html#a24f359f485d2eb14dd38615f96cfc757',1,'Impinj.OctaneSdk.AntennaConfig.AntennaConfig(ushort NewPortNumber)']]],
  ['applydefaultsettings',['ApplyDefaultSettings',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a11486cbb1ad1abbecd0c0eb190eb1877',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['applysettings',['ApplySettings',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a8435999b609993f30dcb1b9fb8577574',1,'Impinj.OctaneSdk.ImpinjReader.ApplySettings(Settings settings)'],['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a3b9b651ccd8614d676de4e9e6c9223d4',1,'Impinj.OctaneSdk.ImpinjReader.ApplySettings(MSG_SET_READER_CONFIG setReaderConfigMessage, MSG_ADD_ROSPEC addRoSpecMessage)']]]
];
