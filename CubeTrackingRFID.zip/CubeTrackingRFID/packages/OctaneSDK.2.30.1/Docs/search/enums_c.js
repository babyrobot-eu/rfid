var searchData=
[
  ['tagfiltermode',['TagFilterMode',['../namespace_impinj_1_1_octane_sdk.html#a64537a0e2934a7ea76dd0a3ff70d8441',1,'Impinj::OctaneSdk']]],
  ['tagfilterop',['TagFilterOp',['../namespace_impinj_1_1_octane_sdk.html#acc0add0807b58695b8a8bafcacd048e2',1,'Impinj::OctaneSdk']]],
  ['taglockstate',['TagLockState',['../namespace_impinj_1_1_octane_sdk.html#a87819741539d830d2366c727e8b87c1f',1,'Impinj::OctaneSdk']]],
  ['tagmodelname',['TagModelName',['../namespace_impinj_1_1_octane_sdk.html#ad7c57c1fb6a9139388d79cd00623880f',1,'Impinj::OctaneSdk']]]
];
