var searchData=
[
  ['querydefaultsettings',['QueryDefaultSettings',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a85e41cdd12cf2757fda494676865f34b',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['queryfeatureset',['QueryFeatureSet',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a5eae0d07c9879c882fb376fad75a4e2b',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['querysettings',['QuerySettings',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a79105aa7e87524bcc2d55160da04bc15',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['querystatus',['QueryStatus',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#aa191e625047bf0e8eaea9803121256f0',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['querytags',['QueryTags',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#ac0649f3d942da9f782bef946127f48ac',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
