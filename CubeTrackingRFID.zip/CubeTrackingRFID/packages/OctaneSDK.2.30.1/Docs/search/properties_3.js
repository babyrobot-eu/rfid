var searchData=
[
  ['data',['Data',['../class_impinj_1_1_octane_sdk_1_1_location_confidence_factors.html#a4b6ac7dda0c2fde1ba60df54f03cdbfd',1,'Impinj.OctaneSdk.LocationConfidenceFactors.Data()'],['../class_impinj_1_1_octane_sdk_1_1_target_tag.html#a55621b8fa926a7157c427d455f4793d9',1,'Impinj.OctaneSdk.TargetTag.Data()']]],
  ['dataprofile',['DataProfile',['../class_impinj_1_1_octane_sdk_1_1_tag_qt_get_op_result.html#a2543809d9fb368623b901dc8badba5b7',1,'Impinj.OctaneSdk.TagQtGetOpResult.DataProfile()'],['../class_impinj_1_1_octane_sdk_1_1_tag_qt_set_op.html#afff7f19e0d9e2bfd93347a751157ce18',1,'Impinj.OctaneSdk.TagQtSetOp.DataProfile()']]],
  ['debounceinms',['DebounceInMs',['../class_impinj_1_1_octane_sdk_1_1_gpi_config.html#a02cbc076b6ede35676eaa387d145bc2f',1,'Impinj::OctaneSdk::GpiConfig']]],
  ['debug',['Debug',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a19e2f6ee444efe80b5a4be91f82afcf1',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['diagnosticreportenabled',['DiagnosticReportEnabled',['../class_impinj_1_1_octane_sdk_1_1_direction_config.html#a56eb96f89a15ee73593cf0bfb09c5634',1,'Impinj.OctaneSdk.DirectionConfig.DiagnosticReportEnabled()'],['../class_impinj_1_1_octane_sdk_1_1_location_config.html#ad85d15fcf96fc085fa4b8a6c399e548a',1,'Impinj.OctaneSdk.LocationConfig.DiagnosticReportEnabled()']]],
  ['direction',['Direction',['../class_impinj_1_1_octane_sdk_1_1_spatial_config.html#a6c85593231bc32bed2058da208efd1b0',1,'Impinj.OctaneSdk.SpatialConfig.Direction()'],['../class_impinj_1_1_octane_sdk_1_1_x_array_config.html#acd7cd1b0171702e51a6f1c0d5835be60',1,'Impinj.OctaneSdk.XArrayConfig.Direction()']]],
  ['directiondiagnosticdata',['DirectionDiagnosticData',['../class_impinj_1_1_octane_sdk_1_1_direction_report.html#a1be580c70aa32ab3cc696ccc13bb9a41',1,'Impinj::OctaneSdk::DirectionReport']]],
  ['disabledantennalist',['DisabledAntennaList',['../class_impinj_1_1_octane_sdk_1_1_location_config.html#a66c1b273e213ef23c78f96e215c7f16c',1,'Impinj::OctaneSdk::LocationConfig']]],
  ['durationinms',['DurationInMs',['../class_impinj_1_1_octane_sdk_1_1_auto_stop_config.html#a430fc9c0d989683897d4a76471522cee',1,'Impinj::OctaneSdk::AutoStopConfig']]]
];
