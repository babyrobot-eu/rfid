var searchData=
[
  ['readerinventorystatus',['ReaderInventoryStatus',['../namespace_impinj_1_1_octane_sdk.html#aa95a9423a738f1bfba44a60213e31b0ca8275c810d29770b13b726feb890e7636',1,'Impinj::OctaneSdk']]],
  ['readerinventorytagsstatus',['ReaderInventoryTagsStatus',['../namespace_impinj_1_1_octane_sdk.html#aa95a9423a738f1bfba44a60213e31b0ca49e3c619d9cc2bcab2fa2a1abc8aac14',1,'Impinj::OctaneSdk']]],
  ['readeroperationalstatus',['ReaderOperationalStatus',['../namespace_impinj_1_1_octane_sdk.html#aa95a9423a738f1bfba44a60213e31b0ca6af466d3c845beb883ac95e82b3fe143',1,'Impinj::OctaneSdk']]],
  ['readerselected',['ReaderSelected',['../namespace_impinj_1_1_octane_sdk.html#a6d6582203a0d3d7f104ec17f23ef54d4a91dabfee0d6e8213fd03edb88c4745b0',1,'Impinj.OctaneSdk.ReaderSelected()'],['../namespace_impinj_1_1_octane_sdk.html#a458a36c55208763f6be9bde886c0cbc0a91dabfee0d6e8213fd03edb88c4745b0',1,'Impinj.OctaneSdk.ReaderSelected()']]],
  ['reserved',['Reserved',['../namespace_impinj_1_1_octane_sdk.html#a4bd5d248896464d33e724b20013f8f8ca942d4e37dd5607ab68e54755540d4a47',1,'Impinj::OctaneSdk']]],
  ['rf_5fpower',['RF_Power',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7eea3c472e3c7654d32714e74eb126edc19b',1,'Impinj::OctaneSdk']]],
  ['rf_5fpower_5fon_5fhub_5f1',['RF_Power_On_Hub_1',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7eea954c4dd81185cec937b8422f49903351',1,'Impinj::OctaneSdk']]],
  ['rf_5fpower_5fon_5fhub_5f2',['RF_Power_On_Hub_2',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7eeab21e50e23a726f63f7930652cf2baea6',1,'Impinj::OctaneSdk']]],
  ['rf_5fpower_5fon_5fhub_5f3',['RF_Power_On_Hub_3',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7eeabf31a9dbf11c332d8fd8b9c527db60b5',1,'Impinj::OctaneSdk']]],
  ['rf_5fpower_5fon_5fhub_5f4',['RF_Power_On_Hub_4',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7eeae02702318da0cb07dfbe3c0ca3174fa1',1,'Impinj::OctaneSdk']]]
];
