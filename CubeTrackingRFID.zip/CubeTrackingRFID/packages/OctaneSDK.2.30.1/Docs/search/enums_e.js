var searchData=
[
  ['xarraymode',['XArrayMode',['../namespace_impinj_1_1_octane_sdk.html#abdba5d5fcd3480a7fc726fc6fb6611f6',1,'Impinj::OctaneSdk']]]
];
