var searchData=
[
  ['placementconfig',['PlacementConfig',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html',1,'Impinj::OctaneSdk']]]
];
