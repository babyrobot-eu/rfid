var searchData=
[
  ['gpomode',['GpoMode',['../namespace_impinj_1_1_octane_sdk.html#aa95a9423a738f1bfba44a60213e31b0c',1,'Impinj::OctaneSdk']]]
];
