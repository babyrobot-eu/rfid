var searchData=
[
  ['keepaliveconfig',['KeepaliveConfig',['../class_impinj_1_1_octane_sdk_1_1_keepalive_config.html',1,'Impinj::OctaneSdk']]],
  ['keepalivereceived',['KeepaliveReceived',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#ac4cbbc348fe297477604c44e36d5cb07',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['keepalives',['Keepalives',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a636e887be85aa84f2b3bc856dc2e3e55',1,'Impinj::OctaneSdk::Settings']]],
  ['killpassword',['KillPassword',['../class_impinj_1_1_octane_sdk_1_1_tag_kill_op.html#a859ac6ced91b2d4f83c64686c3abcb94',1,'Impinj.OctaneSdk.TagKillOp.KillPassword()'],['../namespace_impinj_1_1_octane_sdk.html#aad034f83d9b1f2d946584a2f082e5fd0a874ce44cee88251c0aa277c98cafb661',1,'Impinj.OctaneSdk.KillPassword()']]],
  ['killpasswordlocktype',['KillPasswordLockType',['../class_impinj_1_1_octane_sdk_1_1_tag_lock_op.html#af98ac3955dacfccd260f3fcf0357701b',1,'Impinj::OctaneSdk::TagLockOp']]],
  ['killresult',['KillResult',['../class_impinj_1_1_octane_sdk_1_1_kill_tag_result.html#a6a8db09fe5ede05bd387dcea65ddd44f',1,'Impinj.OctaneSdk.KillTagResult.KillResult()'],['../class_impinj_1_1_octane_sdk_1_1_read_tag_memory_result.html#ac6735f86028c7902d870f83641239bce',1,'Impinj.OctaneSdk.ReadTagMemoryResult.KillResult()']]],
  ['killresultstatus',['KillResultStatus',['../namespace_impinj_1_1_octane_sdk.html#ab94f1d682b6c57acc28faf1cfd3a96a1',1,'Impinj::OctaneSdk']]],
  ['killtagresult',['KillTagResult',['../class_impinj_1_1_octane_sdk_1_1_kill_tag_result.html',1,'Impinj::OctaneSdk']]],
  ['korea_5fmic_5farticle_5f5_5f2',['Korea_MIC_Article_5_2',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178af0c8821af0261027256a47c3442929ea',1,'Impinj::OctaneSdk']]]
];
