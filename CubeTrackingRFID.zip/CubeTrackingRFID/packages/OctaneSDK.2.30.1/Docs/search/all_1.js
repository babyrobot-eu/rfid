var searchData=
[
  ['batchafterstop',['BatchAfterStop',['../namespace_impinj_1_1_octane_sdk.html#ad34181e7bbd29961671edde24b9fc885aa848a54439c83bdb8a8471801b4a7c85',1,'Impinj::OctaneSdk']]],
  ['bitcount',['BitCount',['../class_impinj_1_1_octane_sdk_1_1_tag_filter.html#a218a549e4a8877554e190dfe14753a75',1,'Impinj::OctaneSdk::TagFilter']]],
  ['bitlength',['BitLength',['../class_impinj_1_1_octane_sdk_1_1_margin_read_mask.html#a0bbf34dfb9ba18663c876f3fc0004d00',1,'Impinj::OctaneSdk::MarginReadMask']]],
  ['bitpointer',['BitPointer',['../class_impinj_1_1_octane_sdk_1_1_tag_filter.html#aaf0f5ca0d04cc8c04d429f5dcd73b974',1,'Impinj.OctaneSdk.TagFilter.BitPointer()'],['../class_impinj_1_1_octane_sdk_1_1_tag_margin_read_op.html#afae7e806cdfc8ed984fff6ce6489f2ad',1,'Impinj.OctaneSdk.TagMarginReadOp.BitPointer()'],['../class_impinj_1_1_octane_sdk_1_1_target_tag.html#a46c0fda8772d4024a52f3740d09ff139',1,'Impinj.OctaneSdk.TargetTag.BitPointer()']]],
  ['blockmask',['BlockMask',['../class_impinj_1_1_octane_sdk_1_1_tag_block_permalock_op.html#ac9b4f7909e7caa64b7bc4fbe86093761',1,'Impinj::OctaneSdk::TagBlockPermalockOp']]],
  ['blockpermalockmask',['BlockPermalockMask',['../class_impinj_1_1_octane_sdk_1_1_block_permalock_mask.html',1,'Impinj::OctaneSdk']]],
  ['blockpermalockresult',['BlockPermalockResult',['../namespace_impinj_1_1_octane_sdk.html#a95fae1afe8fed41c5a0c4b67271a0271',1,'Impinj::OctaneSdk']]],
  ['blockwriteenabled',['BlockWriteEnabled',['../class_impinj_1_1_octane_sdk_1_1_tag_op_sequence.html#a15adad744566281bea079bc983722725',1,'Impinj::OctaneSdk::TagOpSequence']]],
  ['blockwriteretrycount',['BlockWriteRetryCount',['../class_impinj_1_1_octane_sdk_1_1_tag_op_sequence.html#a4e607729ea5dae7be8b76c033925ff6d',1,'Impinj::OctaneSdk::TagOpSequence']]],
  ['blockwritewordcount',['BlockWriteWordCount',['../class_impinj_1_1_octane_sdk_1_1_tag_op_sequence.html#ad6b5e0bdb49edd4e54b95e28616cb097',1,'Impinj::OctaneSdk::TagOpSequence']]],
  ['buildaddrospecmessage',['BuildAddROSpecMessage',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a0649416376468dec3d392517087d3c2b',1,'Impinj::OctaneSdk::ImpinjReader']]],
  ['buildsetreaderconfigmessage',['BuildSetReaderConfigMessage',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#aeedebcdb9a53ba2114b00669e4801326',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
