var searchData=
[
  ['pcbits',['PcBits',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a7802e57131448f7662f638d8ad388563',1,'Impinj::OctaneSdk::Tag']]],
  ['peakrssiindbm',['PeakRssiInDbm',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a6d04fd282c5c45852faff5dd75fcb7da',1,'Impinj::OctaneSdk::Tag']]],
  ['periodinms',['PeriodInMs',['../class_impinj_1_1_octane_sdk_1_1_auto_start_config.html#a5e2e65b758ed2971b387e09860241b80',1,'Impinj.OctaneSdk.AutoStartConfig.PeriodInMs()'],['../class_impinj_1_1_octane_sdk_1_1_keepalive_config.html#ae49ccb5f2266901fc03709a28bbfc175',1,'Impinj.OctaneSdk.KeepaliveConfig.PeriodInMs()']]],
  ['persistence',['Persistence',['../class_impinj_1_1_octane_sdk_1_1_tag_qt_set_op.html#aa4929ca8981c52a566f984d60d9d52e4',1,'Impinj::OctaneSdk::TagQtSetOp']]],
  ['phaseangleinradians',['PhaseAngleInRadians',['../class_impinj_1_1_octane_sdk_1_1_tag.html#a8ff81bcc83cec92a0baa2a1d54402978',1,'Impinj::OctaneSdk::Tag']]],
  ['placement',['Placement',['../class_impinj_1_1_octane_sdk_1_1_spatial_config.html#a869106b11ee54d7f2e5001063326a4a3',1,'Impinj.OctaneSdk.SpatialConfig.Placement()'],['../class_impinj_1_1_octane_sdk_1_1_x_array_config.html#a774d483a42ebbfc3610bf81e8e418663',1,'Impinj.OctaneSdk.XArrayConfig.Placement()']]],
  ['portname',['PortName',['../class_impinj_1_1_octane_sdk_1_1_antenna_config.html#a25f9a15ba56625a3387fef10cc0e6e20',1,'Impinj::OctaneSdk::AntennaConfig']]],
  ['portnumber',['PortNumber',['../class_impinj_1_1_octane_sdk_1_1_antenna_config.html#acac40576e99e38c1323136a9aa51f0e3',1,'Impinj.OctaneSdk.AntennaConfig.PortNumber()'],['../class_impinj_1_1_octane_sdk_1_1_antenna_status.html#a3e5917572968704f0b8b1a7adfabe58c',1,'Impinj.OctaneSdk.AntennaStatus.PortNumber()'],['../class_impinj_1_1_octane_sdk_1_1_gpi_config.html#aa52ef389d1fe4e7f729579a47f3bfedc',1,'Impinj.OctaneSdk.GpiConfig.PortNumber()'],['../class_impinj_1_1_octane_sdk_1_1_gpi_status.html#ae0257d2f8ca68e7c7a9f5cb62be55dc0',1,'Impinj.OctaneSdk.GpiStatus.PortNumber()'],['../class_impinj_1_1_octane_sdk_1_1_gpo_config.html#ac1eea6d1e76c3bde26398058b9977473',1,'Impinj.OctaneSdk.GpoConfig.PortNumber()']]]
];
