var searchData=
[
  ['impinj',['Impinj',['../namespace_octane_sdk_1_1_impinj.html',1,'OctaneSdk']]],
  ['octanesdk',['OctaneSdk',['../namespace_octane_sdk.html',1,'OctaneSdk'],['../namespace_octane_sdk_1_1_impinj_1_1_octane_sdk.html',1,'OctaneSdk.Impinj.OctaneSdk']]]
];
