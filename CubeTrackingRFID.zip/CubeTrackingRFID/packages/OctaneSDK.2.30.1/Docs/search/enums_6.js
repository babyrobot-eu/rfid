var searchData=
[
  ['killresultstatus',['KillResultStatus',['../namespace_impinj_1_1_octane_sdk.html#ab94f1d682b6c57acc28faf1cfd3a96a1',1,'Impinj::OctaneSdk']]]
];
