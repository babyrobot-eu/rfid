var searchData=
[
  ['heightcm',['HeightCm',['../class_impinj_1_1_octane_sdk_1_1_placement_config.html#a708f5f9e6944c5b0599d0240f03496d0',1,'Impinj::OctaneSdk::PlacementConfig']]],
  ['highperformance',['HighPerformance',['../namespace_impinj_1_1_octane_sdk.html#ad934a5eb92c6e0396e1e49bfd403b3a7afc3d9ab96ac1103a7581af5eade2ad15',1,'Impinj::OctaneSdk']]],
  ['highsensitivity',['HighSensitivity',['../namespace_impinj_1_1_octane_sdk.html#ad934a5eb92c6e0396e1e49bfd403b3a7ac70c8b65f75e936ad318d4bd59357726',1,'Impinj::OctaneSdk']]],
  ['holdreportsondisconnect',['HoldReportsOnDisconnect',['../class_impinj_1_1_octane_sdk_1_1_settings.html#a88847a0d0248f1d856e499f46ca86753',1,'Impinj::OctaneSdk::Settings']]],
  ['hong_5fkong_5fofta_5f1049',['Hong_Kong_OFTA_1049',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178a5d23c7ebf568de93baf9905d87d9392b',1,'Impinj::OctaneSdk']]],
  ['hubconnectedstatus',['HubConnectedStatus',['../namespace_impinj_1_1_octane_sdk.html#a04b004158e90a2e5da4f16119954197f',1,'Impinj::OctaneSdk']]],
  ['hubfaultstatus',['HubFaultStatus',['../namespace_impinj_1_1_octane_sdk.html#aaf458f7a79dc1fa94430b71e0e25b7ee',1,'Impinj::OctaneSdk']]],
  ['hubid',['HubId',['../class_impinj_1_1_octane_sdk_1_1_antenna_hub_status.html#a2b4779e1615d3227d32ace64c532844e',1,'Impinj::OctaneSdk::AntennaHubStatus']]],
  ['hybrid',['Hybrid',['../namespace_impinj_1_1_octane_sdk.html#a4c4c3a5adf0a8a35f0a6b0f0fc14b438afb1b6e23a3767d2a31ef7899e6dd3f1e',1,'Impinj::OctaneSdk']]]
];
