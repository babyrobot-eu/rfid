var searchData=
[
  ['batchafterstop',['BatchAfterStop',['../namespace_impinj_1_1_octane_sdk.html#ad34181e7bbd29961671edde24b9fc885aa848a54439c83bdb8a8471801b4a7c85',1,'Impinj::OctaneSdk']]]
];
