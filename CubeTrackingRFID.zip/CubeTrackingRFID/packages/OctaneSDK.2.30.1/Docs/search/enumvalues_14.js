var searchData=
[
  ['waitforquery',['WaitForQuery',['../namespace_impinj_1_1_octane_sdk.html#ad34181e7bbd29961671edde24b9fc885a49bfdf7c4f313a7a6b0186e7e9519666',1,'Impinj::OctaneSdk']]],
  ['wide',['Wide',['../namespace_impinj_1_1_octane_sdk.html#a6d6582203a0d3d7f104ec17f23ef54d4ae7c770a61dbdf81ca922ae0260e327c1',1,'Impinj::OctaneSdk']]],
  ['wideareamonitor',['WideAreaMonitor',['../namespace_impinj_1_1_octane_sdk.html#abdba5d5fcd3480a7fc726fc6fb6611f6a207f8df2b0faa37ba24b89f1fc688a83',1,'Impinj::OctaneSdk']]]
];
