var searchData=
[
  ['communicationsstandardtype',['CommunicationsStandardType',['../namespace_impinj_1_1_octane_sdk.html#a433e115903033cb889055cd2518ac178',1,'Impinj::OctaneSdk']]],
  ['connectasyncresult',['ConnectAsyncResult',['../namespace_impinj_1_1_octane_sdk.html#acad5e3eba18b1366dcd599a133e568a4',1,'Impinj::OctaneSdk']]]
];
