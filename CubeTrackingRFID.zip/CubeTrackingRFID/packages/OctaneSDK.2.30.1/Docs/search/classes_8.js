var searchData=
[
  ['marginreadmask',['MarginReadMask',['../class_impinj_1_1_octane_sdk_1_1_margin_read_mask.html',1,'Impinj::OctaneSdk']]]
];
