var searchData=
[
  ['writeresultstatus',['WriteResultStatus',['../namespace_impinj_1_1_octane_sdk.html#a8e0848476e64a10120990eff2482d65e',1,'Impinj::OctaneSdk']]]
];
