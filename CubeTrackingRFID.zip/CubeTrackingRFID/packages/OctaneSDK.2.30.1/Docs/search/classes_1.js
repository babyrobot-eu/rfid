var searchData=
[
  ['blockpermalockmask',['BlockPermalockMask',['../class_impinj_1_1_octane_sdk_1_1_block_permalock_mask.html',1,'Impinj::OctaneSdk']]]
];
