var searchData=
[
  ['readtagmemoryparams',['ReadTagMemoryParams',['../class_impinj_1_1_octane_sdk_1_1_read_tag_memory_params.html#a37bfcccdce6ce7eac508ac1ef2f56281',1,'Impinj::OctaneSdk::ReadTagMemoryParams']]],
  ['resumeeventsandreports',['ResumeEventsAndReports',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a575fa7f498512e6d12a97317a1a30a71',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
