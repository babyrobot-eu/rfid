var searchData=
[
  ['antennachanged',['AntennaChanged',['../class_impinj_1_1_octane_sdk_1_1_impinj_reader.html#a65831ba32640aa187cedd0f0e19c0ea7',1,'Impinj::OctaneSdk::ImpinjReader']]]
];
